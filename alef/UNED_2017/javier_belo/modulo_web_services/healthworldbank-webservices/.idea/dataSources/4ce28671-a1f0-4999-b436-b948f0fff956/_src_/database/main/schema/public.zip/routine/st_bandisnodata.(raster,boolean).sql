create function st_bandisnodata(rast raster, forcechecking boolean) returns boolean
LANGUAGE SQL
AS $$
SELECT st_bandisnodata($1, 1, $2)
$$;
