create function st_quantile(rastertable text, rastercolumn text, nband integer, exclude_nodata_value boolean, quantile double precision) returns double precision
LANGUAGE SQL
AS $$
SELECT (_st_quantile($1, $2, $3, $4, 1, ARRAY[$5]::double precision[])).value
$$;
