create function st_geomfromgml(text) returns geometry
LANGUAGE SQL
AS $$
SELECT _ST_GeomFromGML($1, 0)
$$;
