create function st_distance(geography, geography, boolean) returns double precision
LANGUAGE SQL
AS $$
SELECT _ST_Distance($1, $2, 0.0, $3)
$$;
