create function st_count(rast raster, exclude_nodata_value boolean) returns bigint
LANGUAGE SQL
AS $$
SELECT _st_count($1, 1, $2, 1)
$$;
