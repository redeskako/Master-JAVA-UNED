create function "_st_distancetree"(geography, geography) returns double precision
LANGUAGE SQL
AS $$
SELECT _ST_DistanceTree($1, $2, 0.0, true)
$$;
