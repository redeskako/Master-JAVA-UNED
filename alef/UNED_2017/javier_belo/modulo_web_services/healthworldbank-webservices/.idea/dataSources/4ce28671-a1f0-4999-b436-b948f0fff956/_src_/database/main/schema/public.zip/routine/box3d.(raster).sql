create function box3d(raster) returns box3d
LANGUAGE SQL
AS $$
select box3d(st_convexhull($1))
$$;
