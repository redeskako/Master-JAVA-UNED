create function raster_geometry_overlap(raster, geometry) returns boolean
LANGUAGE SQL
AS $$
select $1::geometry && $2
$$;
