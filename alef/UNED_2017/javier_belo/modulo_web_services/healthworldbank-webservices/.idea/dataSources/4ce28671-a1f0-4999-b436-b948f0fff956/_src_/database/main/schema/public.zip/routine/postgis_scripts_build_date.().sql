create function postgis_scripts_build_date() returns text
LANGUAGE SQL
AS $$
SELECT '2016-03-30 18:02:52'::text AS version
$$;
