create function st_mem_size(geometry) returns integer
LANGUAGE SQL
AS $$
SELECT _postgis_deprecate('ST_Mem_Size', 'ST_MemSize', '2.2.0');
    SELECT ST_MemSize($1);

$$;
