create function st_valuepercent(rast raster, nband integer, searchvalues double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT percent double precision) returns SETOF record
LANGUAGE SQL
AS $$
SELECT value, percent FROM _st_valuecount($1, $2, TRUE, $3, $4)
$$;
