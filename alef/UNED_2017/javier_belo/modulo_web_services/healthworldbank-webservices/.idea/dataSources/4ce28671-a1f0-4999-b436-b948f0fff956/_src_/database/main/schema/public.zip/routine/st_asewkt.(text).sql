create function st_asewkt(text) returns text
LANGUAGE SQL
AS $$
SELECT ST_AsEWKT($1::geometry);
$$;
