create function geometry_raster_contain(geometry, raster) returns boolean
LANGUAGE SQL
AS $$
select $1 ~ $2::geometry
$$;
