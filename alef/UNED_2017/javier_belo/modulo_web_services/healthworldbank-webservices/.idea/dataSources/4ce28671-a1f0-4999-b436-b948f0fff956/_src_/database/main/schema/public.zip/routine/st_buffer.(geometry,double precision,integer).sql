create function st_buffer(geometry, double precision, integer) returns geometry
LANGUAGE SQL
AS $$
SELECT _ST_Buffer($1, $2,
		CAST('quad_segs='||CAST($3 AS text) as cstring))

$$;
