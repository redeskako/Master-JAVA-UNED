create function st_askml(version integer, geom geometry, maxdecimaldigits integer DEFAULT 15, nprefix text DEFAULT NULL::text) returns text
LANGUAGE SQL
AS $$
SELECT _ST_AsKML($1, ST_Transform($2,4326), $3, $4);
$$;
