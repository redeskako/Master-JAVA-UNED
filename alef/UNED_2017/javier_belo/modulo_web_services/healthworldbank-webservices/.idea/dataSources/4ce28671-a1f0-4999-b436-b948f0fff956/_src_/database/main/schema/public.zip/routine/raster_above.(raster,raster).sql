create function raster_above(raster, raster) returns boolean
LANGUAGE SQL
AS $$
select $1::geometry |>> $2::geometry
$$;
