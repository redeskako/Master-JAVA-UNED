create function st_astext(text) returns text
LANGUAGE SQL
AS $$
SELECT ST_AsText($1::geometry);
$$;
