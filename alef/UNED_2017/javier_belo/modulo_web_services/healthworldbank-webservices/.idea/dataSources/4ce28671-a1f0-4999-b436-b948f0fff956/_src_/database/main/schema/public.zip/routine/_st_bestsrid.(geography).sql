create function "_st_bestsrid"(geography) returns integer
LANGUAGE SQL
AS $$
SELECT _ST_BestSRID($1,$1)
$$;
