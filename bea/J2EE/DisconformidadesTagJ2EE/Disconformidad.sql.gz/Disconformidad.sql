-- phpMyAdmin SQL Dump
-- version 3.5.8.1deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 03-07-2013 a las 23:56:48
-- Versión del servidor: 5.5.31-0ubuntu0.13.04.1
-- Versión de PHP: 5.4.9-4ubuntu2.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `disconformidad`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Disconformidad`
--

CREATE TABLE IF NOT EXISTS `Disconformidad` (
  `numero` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `docs` varchar(100) DEFAULT NULL,
  `servicio` int(10) unsigned DEFAULT NULL,
  `idusuario` int(10) unsigned DEFAULT NULL,
  `devolucion` tinyint(1) DEFAULT NULL,
  `motivo` varchar(100) DEFAULT NULL,
  `comentario` varchar(100) NOT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `Disconformidad`
--

INSERT INTO `Disconformidad` (`numero`, `fecha`, `docs`, `servicio`, `idusuario`, `devolucion`, `motivo`, `comentario`) VALUES
(1, '2013-06-05', 'Prueba', 1, 1, NULL, NULL, 'Prueba'),
(2, '2013-06-04', 'Prueba2', 1, 1, NULL, NULL, 'prueba2');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
